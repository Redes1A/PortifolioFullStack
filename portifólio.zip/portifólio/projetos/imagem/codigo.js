let var1 = 1;
var var2 = "Aracaju";
const var3 = 234234;
let var4 = var1 + var3;
alert(var2);

